import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct MapView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )

    var body: some View {
            VStack {
                Map(coordinateRegion: $region, interactionModes: .all, showsUserLocation: true)
                    .ignoresSafeArea()
                    .gesture(DragGesture())
                    .onLongPressGesture {
                    }

                VStack {
                    HStack {
                        Text("**GreyhoundGrub**")
                            .font(.system(size: 28))
                            .foregroundColor(.green)
                    }
                    VStack {
                        Spacer()
                        Text("Estimated wait [TIME]")
                        Text("**[PERSON]**")
                        Text("is delivering your food from [LOCATION]")
                        Spacer()
                        Spacer()
                    }
                    .foregroundColor(.green)
                    .tint(.green)
                    Spacer()
                }
            }
            .onAppear{
                locationManager.requestLocation()
            }
    }
}


class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var region: MKCoordinateRegion?

    override init() {
        super.init()
        manager.delegate = self
        requestLocation()
        
        // For Preview Testing Comment This Out
        location = CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172)
    }

    func requestLocation() {
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first?.coordinate else { return }
        self.location = location
        self.region = MKCoordinateRegion(
            center: location,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}


struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}
