//
//  DesignTestFile.swift
//  GreyhoundHub
//
//  Created by Student on 11/30/23.
//

import SwiftUI

struct StartView: View{
    
    @State private var isLoginViewPresented = false
    @State private var isWorkerLoginViewPresented = false
    @Binding var isLoggedIn: Bool
    @Binding var username: String
    @Binding var isWorker: Bool
    
    
    var body: some View{
        
        ZStack {
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack {
                Text("GreyhoundGrub")
                    .font(.system(size: 48))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 40)
                
                Spacer()
                
                VStack {
                    Spacer()
                    Spacer()
                    Button(action: {
                        isLoginViewPresented = true
                    }) {
                        Text("Student")
                            .foregroundColor(.white)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 60)
                            .frame(minWidth: 300)
                            .background(Color.mint.opacity(0.7))
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $isLoginViewPresented) {
                        LoginView(username: $username, isLoggedIn: $isLoggedIn, showingLoginSheet: $isLoginViewPresented, isWorker: $isWorker)
                    }
                    .padding(30)
                    Button(action: {
                        isWorkerLoginViewPresented = true
                    }) {
                        Text("Worker")
                            .foregroundColor(.white)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 60)
                            .frame(minWidth: 300)
                            .background(Color.mint.opacity(0.7))
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $isWorkerLoginViewPresented) {
                        WorkerLoginView(username: $username, isLoggedIn: $isLoggedIn, showingLoginSheet: $isWorkerLoginViewPresented, worker: $isWorker)
                    }
                    
                    Spacer()
                    Spacer()
                    
                }
                Spacer()
                Image("greyhoundlogo")
                    .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0), resizingMode: .stretch)
                    .padding(60)
            }
        }
    }
}
