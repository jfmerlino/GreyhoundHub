import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct MapView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )

    var body: some View {
            VStack {
                Map(coordinateRegion: $region, interactionModes: .all, showsUserLocation: true)
                    .ignoresSafeArea()
                    .gesture(DragGesture())
                    .onLongPressGesture {
                    }

                VStack {
                    HStack {
                        Text("**GreyhoundGrub**")
                            .font(.system(size: 28))
                            .foregroundColor(.green)
                    }
                    VStack {
                        Spacer()
                        Text("Estimated wait [TIME]")
                        Text("**[PERSON]**")
                        Text("is delivering your food from [LOCATION]")
                        Spacer()
                        Spacer()
                    }
                    .foregroundColor(.green)
                    .tint(.green)
                    Spacer()
                }
            }
    }
}



struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}
