//
//  ContentView.swift
//  GreyhoundHub
//
//  Created by Student on 11/2/23.
//

import SwiftUI
import Foundation


struct ContentView: View {
    @ObservedObject var postViewModel = PostViewModel()
    @State private var showingSheet = false
    @State private var isLoginViewPresented = false
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                Text("GreyhoundHub")
                    .font(.system(size: 48))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 40)
                
                Spacer()
                
                HStack {
                    Button(action: {
                        // Add action for "Worker" button here
                    }) {
                        Text("Worker")
                            .foregroundColor(.gray)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 120)
                            .background(Color.mint)
                            .cornerRadius(10)
                    }
                    
                    Button(action: {
                        isLoginViewPresented = true
                    }) {
                        Text("Student")
                            .foregroundColor(.mint)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 120)
                            .background(Color.gray)
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $isLoginViewPresented) {
                        LoginView()
                    }
                }
                
                Spacer()
            }
        }
    }
}

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isCreatingAccount = false
    @State private var loginError: String? = nil
    @State private var isCreatingBypass = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.green, .mint],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                Text("Login Page")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                Spacer()
                
                TextField("Username", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Spacer()

                if let error = loginError {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }

                Button(action: {
                    APIService().getUser(by: username) { result in
                        switch result {
                        case .success(let user):
                            if let userPassword = user["password"] as? String, userPassword == password {
                                isCreatingBypass = true
                                    
                            } else {
                                self.loginError = "Invalid username or password"
                            }
                        case .failure(_):
                            self.loginError = "User not found"
                        }
                    }
                }) {
                    Text("Login")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                        .frame(maxWidth: 300)
                }
                .buttonStyle(.borderedProminent)
                
                Spacer()
                
                Button(action: {
                    isCreatingAccount = true
                }) {
                    Text("Create New Account")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $isCreatingAccount) {
                    CreateAccountView()
                }
            }.sheet(isPresented: $isCreatingBypass) {
                CreateBypassView()
            }
        }
    }
}

struct CreateAccountView: View {
    @State private var newUsername = ""
    @State private var newPassword = ""
    @State private var accountCreationStatus: String? = nil
    @State private var accountCreationSuccessful = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Create Account")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                
                TextField("Username", text: $newUsername)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $newPassword)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                if let status = accountCreationStatus {
                    Text(status)
                        .foregroundColor(accountCreationSuccessful ? .green : .red)
                        .padding()
                }
                
                Button(action: {
                    APIService().createUser(username: newUsername, password: newPassword) { result in
                        switch result {
                        case .success:
                            accountCreationStatus = "Account created successfully!"
                            accountCreationSuccessful = true
                        case .failure(_):
                            accountCreationStatus = "Created"
                            accountCreationSuccessful = false
                        }
                    }
                }) {
                    Text("Create Account")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
        }
    }
}

struct CreateBypassView: View {
    @State private var orderingIggy = false
    @State private var orderingBoulder = false
    @State private var orderingGreenGrey = false
    @State private var orderingStarbucks = false
    
    var body: some View{
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack{
                Spacer()
                
                Text("Please choose which dining hall you ordered from.")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                Spacer()
                
                Button(action: {
                    orderingIggy = true
                }) {
                    Text("Iggy")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingIggy) {
                    CreateIggyView()
                }
                
                Spacer()
                
                Button(action: {
                    orderingBoulder = true
                }) {
                    Text("Boulder")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingBoulder) {
                    CreateBoulderView()
                }
                
                Spacer()
                
                Button(action: {
                    orderingGreenGrey = true
                }) {
                    Text("Green & Grey")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingGreenGrey) {
                    CreateGreenGreyView()
                }

                
                Spacer()
                
                Button(action: {
                    orderingStarbucks = true
                }) {
                    Text("Starbucks")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingStarbucks) {
                    CreateStarbucksView()
                }


            }
        }
    }
}

struct CreateIggyView: View {
    @State var grubhubNumber = ""
    @State var grubhubName = ""
    @State var beingPickedUp = ""
    @State var locationDropoff = ""
    @State var extra = ""
    
    var body: some View {
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Please enter your Grubhub Number:")
                    .font(.headline)
                TextField("Grubhub Number", text: $grubhubNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter your Grubhub name for extra security purposes:")
                    .font(.headline)
                TextField("Name", text: $grubhubName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter what is being picked up:")
                    .font(.headline)
                TextField("Pickup", text: $beingPickedUp)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter dropoff location:")
                    .font(.headline)
                TextField("Location", text: $locationDropoff)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Additional comments or requests:")
                    .font(.headline)
                TextField("Extras", text: $extra)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .padding()
        }
    }
}


struct CreateBoulderView: View {
    @State var grubhubNumber = ""
    @State var grubhubName = ""
    @State var beingPickedUp = ""
    @State var locationDropoff = ""
    @State var extra = ""
    
    var body: some View {
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Please enter your Grubhub Number:")
                    .font(.headline)
                TextField("Grubhub Number", text: $grubhubNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter your Grubhub name for extra security purposes:")
                    .font(.headline)
                TextField("Name", text: $grubhubName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter what is being picked up:")
                    .font(.headline)
                TextField("Pickup", text: $beingPickedUp)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter dropoff location:")
                    .font(.headline)
                TextField("Location", text: $locationDropoff)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Additional comments or requests:")
                    .font(.headline)
                TextField("Extras", text: $extra)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .padding()
        }
    }
}

struct CreateGreenGreyView: View {
    @State var grubhubNumber = ""
    @State var grubhubName = ""
    @State var beingPickedUp = ""
    @State var locationDropoff = ""
    @State var extra = ""
    
    var body: some View {
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Please enter your Grubhub Number:")
                    .font(.headline)
                TextField("Grubhub Number", text: $grubhubNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter your Grubhub name for extra security purposes:")
                    .font(.headline)
                TextField("Name", text: $grubhubName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter what is being picked up:")
                    .font(.headline)
                TextField("Pickup", text: $beingPickedUp)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter dropoff location:")
                    .font(.headline)
                TextField("Location", text: $locationDropoff)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Additional comments or requests:")
                    .font(.headline)
                TextField("Extras", text: $extra)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .padding()
        }
    }
}

struct CreateStarbucksView: View {
    @State var grubhubNumber = ""
    @State var grubhubName = ""
    @State var beingPickedUp = ""
    @State var locationDropoff = ""
    @State var extra = ""
    
    var body: some View {
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Please enter your Grubhub Number:")
                    .font(.headline)
                TextField("Grubhub Number", text: $grubhubNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter your Grubhub name for extra security purposes:")
                    .font(.headline)
                TextField("Name", text: $grubhubName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter what is being picked up:")
                    .font(.headline)
                TextField("Pickup", text: $beingPickedUp)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter dropoff location:")
                    .font(.headline)
                TextField("Location", text: $locationDropoff)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Additional comments or requests:")
                    .font(.headline)
                TextField("Extras", text: $extra)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .padding()
        }
    }
}

class PostViewModel: ObservableObject {
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
