//
//  BoulderView.swift
//  GreyhoundHub
//
//  Created by Alex Kristian on 11/6/23.
//

import SwiftUI

struct CreateBoulderView: View {
    @Binding var showingSheet: Bool
    @State var grubhubNumber = ""
    @State var grubhubName = ""
    @State var beingPickedUp = ""
    @State var locationDropoff = ""
    @State var extra = ""
    
    var body: some View {
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 20) {
                HStack{
                    Spacer()
                    Button("X"){
                        showingSheet = false
                    }
                    .foregroundColor(Color.red)
                    .padding()
                    .font(.largeTitle)
                    .bold()
                }
                
                Text("Boulder")
                    .font(.system(size: 48))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("Please enter your Grubhub Number:")
                    .font(.headline)
                TextField("Grubhub Number", text: $grubhubNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter your Grubhub name for extra security purposes:")
                    .font(.headline)
                TextField("Name", text: $grubhubName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter what is being picked up:")
                    .font(.headline)
                TextField("Pickup", text: $beingPickedUp)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Please enter dropoff location:")
                    .font(.headline)
                TextField("Location", text: $locationDropoff)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("Additional comments or requests:")
                    .font(.headline)
                TextField("Extras", text: $extra)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .padding()
        }
    }
}
