//
//  ByPassView.swift
//  GreyhoundHub
//
//  Created by Alex Kristian on 11/6/23.
//
import SwiftUI

struct CreateBypassView: View {
    @State private var orderingIggy = false
    @State private var orderingBoulder = false
    @State private var orderingGreenGrey = false
    @State private var orderingStarbucks = false
    @State private var isShowingAccountSheet = false
    @Binding var isLoggedIn: Bool
    @Binding var username: String
    
    
    
    var body: some View{
        ZStack{
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack{
                HStack{
                    Spacer()
                    Button(action: {
                        isShowingAccountSheet = true
                    }) {
                        Text("Account")
                            .foregroundColor(.black)
                            .padding()
                    }
                    .sheet(isPresented: $isShowingAccountSheet) {
                        AccountView(showingSheet: $isShowingAccountSheet, loggedIn: $isLoggedIn,
                        username: $username)
                    }
                }
                Text("GreyhoundGrub")
                    .font(.system(size: 48))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    
                Spacer()
                
                Text("Please choose which dining hall you ordered from.")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                Spacer()
                
                Button(action: {
                    orderingIggy = true
                }) {
                    Text("Iggys")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingIggy) {
                    CreateIggysView(showingSheet: $orderingIggy)
                }
                
                Spacer()
                
                Button(action: {
                    orderingBoulder = true
                }) {
                    Text("Boulder")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingBoulder) {
                    CreateBoulderView(showingSheet: $orderingBoulder)
                }
                
                Spacer()
                
                Button(action: {
                    orderingGreenGrey = true
                }) {
                    Text("Green & Grey")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingGreenGrey) {
                    CreateGreenGreyView(showingSheet: $orderingGreenGrey)
                }

                
                Spacer()
                
                Button(action: {
                    orderingStarbucks = true
                }) {
                    Text("Starbucks")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $orderingStarbucks) {
                    CreateStarbucksView(showingSheet: $orderingStarbucks)
                }


            }
        }
    }
}
