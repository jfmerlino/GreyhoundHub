//
//  GreyhoundHubApp.swift
//  GreyhoundHub
//
//  Created by Student on 11/2/23.
//

import SwiftUI

@main
struct GreyhoundHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
