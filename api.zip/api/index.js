const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

// Middleware to parse JSON
app.use(express.json());

// Read users from data.json
const getUsers = () => {
    const data = fs.readFileSync('data.json', 'utf-8');
    return JSON.parse(data).users;
};

// Get all users
app.get('/users', (req, res) => {
    const users = getUsers();
    res.json(users);
});

// Get user by username
app.get('/users/:username', (req, res) => {
    const users = getUsers();
    const user = users.find(u => u.username === req.params.username);
    if (!user) {
        return res.status(404).send('User not found');
    }
    res.json(user);
});

// Create a new user
app.post('/users', (req, res) => {
    const users = getUsers();
    users.push(req.body); // In a real-world application, validate input!
    fs.writeFileSync('data.json', JSON.stringify({ users }));
    res.status(201).send('User created');
});

// Update user details by username
app.put('/users/:username', (req, res) => {
    const users = getUsers();
    const index = users.findIndex(u => u.username === req.params.username);
    if (index === -1) {
        return res.status(404).send('User not found');
    }
    users[index] = req.body;
    fs.writeFileSync('data.json', JSON.stringify({ users }));
    res.send('User updated');
});

// Delete a user by username
app.delete('/users/:username', (req, res) => {
    const users = getUsers();
    const newUsers = users.filter(u => u.username !== req.params.username);
    fs.writeFileSync('data.json', JSON.stringify({ users: newUsers }));
    res.send('User deleted');
});

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
