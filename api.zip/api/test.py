import requests
import json

BASE_URL = "http://localhost:3000"

def test_get_all_users():
    response = requests.get(f"{BASE_URL}/users")
    assert response.status_code == 200
    users = response.json()
    print("All users:", users)

def test_get_user(username):
    response = requests.get(f"{BASE_URL}/users/{username}")
    if response.status_code == 404:
        print(f"User {username} not found")
    else:
        user = response.json()
        print(f"Details of {username}:", user)

def test_create_user(user_data):
    response = requests.post(f"{BASE_URL}/users", json=user_data)
    assert response.status_code == 201
    print(f"User {user_data['username']} created")

def test_update_user(username, updated_data):
    response = requests.put(f"{BASE_URL}/users/{username}", json=updated_data)
    if response.status_code == 404:
        print(f"User {username} not found")
    else:
        print(f"User {username} updated")

def test_delete_user(username):
    response = requests.delete(f"{BASE_URL}/users/{username}")
    if response.status_code == 404:
        print(f"User {username} not found")
    else:
        print(f"User {username} deleted")

if __name__ == "__main__":
    # Testing GET all users
    test_get_all_users()

    # Testing GET a specific user
    test_get_user("alice123")

    # Testing POST a new user
    new_user = {
        "username": "johnDoe",
        "password": "testpassword",
        "occupation": "Tester"
    }
    test_create_user(new_user)

    # Testing PUT (update) a user
    update_data = {
        "username": "johnDoe",
        "password": "newpassword",
        "occupation": "Senior Tester"
    }
    test_update_user("johnDoe", update_data)

    # Testing DELETE a user
    test_delete_user("johnDoe")

    # Fetching all users again to confirm the changes
    test_get_all_users()